package customsExceptions;

import java.io.IOException;

public class UniqueProductException extends IOException {

    private String msg;

    public UniqueProductException(String msg){
        super(msg);
    }


}
