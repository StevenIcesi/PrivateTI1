package customsExceptions;

import java.io.IOException;

public class UniqueUserException extends IOException {

    private String msg;

    public UniqueUserException(String msg){
        super(msg);
    }
}
