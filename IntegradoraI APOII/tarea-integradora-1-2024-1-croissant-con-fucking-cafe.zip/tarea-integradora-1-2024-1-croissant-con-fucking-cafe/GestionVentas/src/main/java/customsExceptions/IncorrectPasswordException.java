package customsExceptions;

import java.io.IOException;

public class IncorrectPasswordException extends IOException {

    private String msg;

    public IncorrectPasswordException(String msg){
        super(msg);
    }
}
