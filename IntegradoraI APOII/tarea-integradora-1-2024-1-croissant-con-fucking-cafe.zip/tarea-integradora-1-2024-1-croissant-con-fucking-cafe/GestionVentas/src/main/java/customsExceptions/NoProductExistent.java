package customsExceptions;

import java.io.IOException;

public class NoProductExistent extends IOException {
    private String msg;
    public NoProductExistent(String msg){
        super(msg);
    }
}
