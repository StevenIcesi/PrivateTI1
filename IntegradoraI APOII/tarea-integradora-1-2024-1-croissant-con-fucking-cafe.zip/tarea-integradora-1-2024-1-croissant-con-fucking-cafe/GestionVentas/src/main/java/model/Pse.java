package model;

public class Pse{
    private String bank;
    private String userPhoneNumber;


    public Pse(String bank, String userPhoneNumber){
        this.bank = bank;
        this.userPhoneNumber = userPhoneNumber;
    }

    public String getBank(){
        return bank;
    }

    public String getUserPhoneNumber(){
        return userPhoneNumber;
    }

    public void setBank(String bank){
        this.bank = bank;
    }

    public void setUserPhoneNumber(String userPhoneNumber){
        this.userPhoneNumber = userPhoneNumber;
    }


}

