package model;

public class Debit extends PaymentMethod {

    public Debit(int cardNumber, int cvv){
        super(cardNumber, cvv);
    }

}
