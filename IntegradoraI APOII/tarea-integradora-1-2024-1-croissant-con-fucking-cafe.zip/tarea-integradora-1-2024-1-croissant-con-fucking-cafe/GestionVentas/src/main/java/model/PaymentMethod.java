
package model;

public class PaymentMethod {

    private int cardNumber;
    private int cvv;

    public PaymentMethod(int cardNumber, int cvv){
        this.cardNumber = cardNumber;
        this.cvv = cvv;
    }

    public int getCardNumber(){
        return cardNumber;
    }

    public void setCardNumber(int cardNumber){
        this.cardNumber = cardNumber;
    }

    public int getCvv(){
        return cvv;
    }

    public void setCvv(int cvv){
        this.cvv = cvv;
    }

    @Override
    public String toString() {
        return "payment method{" +
                "cardNumber=" + cardNumber +
                ", cvv=" + cvv +
                '}';
    }



}
