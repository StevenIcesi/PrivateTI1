package model;
import java.util.Date;

public class Order {

    private PaymentMethod paymentMethod;
    private String buyerName;
    private double price;
    private Date orderDate;

    public Order(PaymentMethod paymentMethod, String buyerName, double price, Date orderDate) {
        this.paymentMethod = paymentMethod;
        this.buyerName = buyerName;
        this.price = price;
        this.orderDate = orderDate;
    }
    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    @Override
    public String toString() {
        return "Order{" + "paymentMethod=" + paymentMethod + ", buyerName=" + buyerName + ", price=" + price + ", orderDate=" + orderDate + '}';
    }






}
