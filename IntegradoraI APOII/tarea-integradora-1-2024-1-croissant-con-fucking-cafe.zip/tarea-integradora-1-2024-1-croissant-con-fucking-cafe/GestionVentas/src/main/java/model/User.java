package model;
import collection.LinkedList;

import java.util.Date;

public class User {

    private String userName;
    private String password;
    private String name;
    private String lastName;
    private Date birthDate;
    private String address;
    private String city;
    private String phone;
    private String email;

    public User(String userName, String password, String name, String lastName, Date birthDate, String address, String city, String phone, String email) {
        this.userName = userName;
        this.password = password;
        this.name = name;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.address = address;
        this.city = city;
        this.phone = phone;
        this.email = email;
    }

    public User(String name, String lastName, String userName, String password, Date birthDate, String address, String city, String email) {
    }

    public String getUserName() {
        return userName;
    }


    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }



    // do getter and setter






}
