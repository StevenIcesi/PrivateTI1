package model;

import collection.LinkedList;
import collection.Node;
import customsExceptions.IncorrectPasswordException;
import customsExceptions.NoProductExistent;
import customsExceptions.UniqueProductException;
import customsExceptions.UniqueUserException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Controller {
    private LinkedList<User> users;
    private Node<User> currentUser;
    private LinkedList<Product> products;

    public Controller() {
        users = new LinkedList<>();
        products = new LinkedList<>();
    }

    // Terminado
    public Date createDates(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Date finalDate = new Date();

        try {
            finalDate = sdf.parse(date);
            return finalDate;

        } catch (ParseException e) {
            System.out.println("an error occurred when transforming the date: " + e.getMessage());
        }

        return finalDate;
    }

    // Terminado
    public boolean verifyPassword(String password) throws IncorrectPasswordException {
        int upper = 0, digit = 0;
        char pass[] = password.toCharArray();

        for (char i : pass) {
            if (Character.isUpperCase(i)) {
                upper++;
            }

            if (Character.isDigit(i)) {
                digit++;
            }
        }

        if (upper > 0 && digit > 0) {
            return true;
        } else {
            throw new IncorrectPasswordException("The password need an Uppercase and/or numbers");
        }
    }

    public boolean verifyUserName(String userName) throws UniqueUserException {
        if (users.searchUserName(userName)) {
            throw new UniqueUserException("The user name must be unique");

        } else {
            return false;
        }
    }

    public boolean verifyProductName(String productName) throws UniqueProductException {
        if (products.searchUserName(productName)) {
            return true;

        } else {
            throw new UniqueProductException("The product name must be Unique");
        }
    }

    // Terminado
    public boolean addUser(String userName, String password, String name, String lastName, String birthDate, String addres, String city, String phone, String email) {
        Date birthDateFormat = createDates(birthDate);
        User user = new User(userName, password, name, lastName, birthDateFormat, addres, city, phone, email);
        users.add(user);

        if (users.contains(user)) {
            return true;

        } else {
            return false;
        }
    }

    // terminado
    public boolean addProduct(String name, double price, int quantity) {

        if (products.searchProductName(name)) {
            return products.increaseProduct(name, quantity);
        } else {
            products.add(new Product(name, price, quantity));
            return false;
        }
    }

    public boolean signIn(String userName, String password) throws IncorrectPasswordException {

        if (users.searchUserName(userName) && users.searchPassword(password)) {
            if (users.searchUser(userName) != null) {
                currentUser = users.searchUser(userName);
                return true;
            }

        } else {
            throw new IncorrectPasswordException("Oh! something happened. Check if the password or user name it's correct");
        }

        return false;
    }


    public void AddOrder() {

    }
    public boolean deleteProduct(String name, int quantity) throws NoProductExistent{
            if(products.searchProductName(name)){
                if(products.decreseProduct(name,quantity)){
                    return true;

                }else { // si retorna false es por que no hay más inventario del producto
                    products.newDelete(products.searchProduct(name));
                    return false;
                }
            }else {
                throw new NoProductExistent("The product does not exist");
            }

    }


    public String updateProduct(String productName, Double price, int quantity) {
        Node<Product> current = products.getFirst();

        while (current != null) {
            Product product = current.getData();
            if (product.getName().equals(productName)) {
                product.setPrice(price);
                product.setQuantity(quantity);

                return "price updated succesfully";
            }
            current = current.getNext();
        }

        return "price not updated";
    }


    public void paymentMethod(String paymenthMethod) {

    }

    public void debit(int cardNumber, int cvv) {

    }

    public void credit(int cardNumber, int cvv, int paymentPlan) {

    }

    public void pse(String bank, String userPhoneNumber) {

    }

    //TODO productos
    public void searchProductAlphabetical(String productName) {

    }

    public void searchProductByCategory(String Category) {

    }

    public void searchProductByPrice(Double price) {

    }

    public void searchProductByTimesBuyed(int timesBuyed) {

    }

   // final
    //TODO ordenes
    public void searchOrderByNameOfTheBuyer(String buyerName) {

    }

    public void searchOrderByTotalPrice(Double price) {

    }

    public void searchOrderByDateBuyed(Date buyedDate) {

    }


}
