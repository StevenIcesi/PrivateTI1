package model;

public class Credit extends PaymentMethod {
    private int quotas;

    public Credit(int cardNumber, int cvv, int quotas) {
        super(cardNumber, cvv);
        this.quotas = quotas;
    }

    public int getQuotas() {
        return quotas;
    }

    public void setQuotas(int quotas) {
        this.quotas = quotas;
    }


}