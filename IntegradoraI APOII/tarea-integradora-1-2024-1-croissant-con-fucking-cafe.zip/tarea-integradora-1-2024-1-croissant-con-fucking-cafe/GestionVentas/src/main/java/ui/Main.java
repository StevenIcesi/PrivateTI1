 package ui;

import customsExceptions.IncorrectPasswordException;
import customsExceptions.UniqueUserException;
import model.Controller;

import java.util.Scanner;

public class Main {

    private Controller controller;
    private Scanner input;

    public static void main(String[] args) {
        Main m = new Main();
        int option;

        do{
            m.menu();
            option = m.input.nextInt();
            m.executeOption(option);


        }while(option != 0 );

        m.input.close();

    }




    public Main() {
        controller = new Controller();
        input = new Scanner(System.in);
    }

    public void menu(){
        System.out.println("""
                0. EXIT
                1. Register
                2. Sign in
                """);

    }

    public void executeOption(int option){
        switch (option){
            case 0 -> {System.out.println("Have a good one! see you soon ;)");}
            case 1 -> {addUser();}
            case 2 -> {signIn();}

        }
    }


    // Terminado
    public void addUser(){

        String userName;
        System.out.println("Enter the user name");
        userName = input.nextLine();

        if (userName.isEmpty()){
            userName = input.nextLine();
        }

        System.out.println("Enter the password");
        String password = input.nextLine();

        try{
            if (controller.verifyPassword(password) && !(controller.verifyUserName(userName))){
                System.out.println("Enter the name");
                String name = input.nextLine();

                System.out.println("Enter the last name");
                String lastName = input.nextLine();

                System.out.println("Enter the birth date in the format [yyyy/MM/dd]");
                String birthDate = input.nextLine();

                System.out.println("Enter the address");
                String address = input.nextLine();

                System.out.println("Enter the city");
                String city = input.nextLine();

                System.out.println("Enter the phone");
                String phone = input.nextLine();

                System.out.println("Enter the email");
                String email = input.nextLine();

                controller.addUser(userName, password, name, lastName, birthDate, address, city, phone, email);
            }

        } catch (IncorrectPasswordException | UniqueUserException e){
            System.out.println(e.getMessage());
        }
    }

    public void signIn(){
        System.out.println("Enter the user name");
        String userName = input.nextLine();

        if (userName.isEmpty()){
            userName = input.nextLine();
        }

        System.out.println("Enter the password");
        String password = input.nextLine();

        try{
            if (controller.signIn(userName, password)){
                System.out.println("You are in!");
            }
        } catch (IncorrectPasswordException e){
            System.out.println(e.getMessage());
        }

    }

    public void menuSignIn(){
        
    }
}
