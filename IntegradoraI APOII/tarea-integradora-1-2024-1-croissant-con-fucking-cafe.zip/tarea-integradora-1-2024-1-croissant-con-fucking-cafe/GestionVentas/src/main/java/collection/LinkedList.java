package collection;

import model.Product;
import model.User;

import java.util.Comparator;

public class LinkedList<T> {

    private Node<T> first;
    private Node<T> last;
    int size;

    public LinkedList() {
        this.first = null;
        this.last = null;
        size = 0;
    }

    // terminado
    public void add(T data) {
        Node<T> newNode = new Node<>(data);
        size++;
        if (first == null) {
            first = newNode;
            last = newNode;
        } else {
                last.setNext(newNode);
                last.getNext().setBack(last);
                last = newNode;
        }
    }

    public boolean searchUserName(String data) {
        Node<T> current = first;

        while (current != null) {
            if (current.getData() instanceof User) {
                User user = (User) current.getData();
                if (user.getUserName().equals(data)) {
                    return true;
                }
            }

            current = current.getNext();
        }
        return false; // No se encontró ningún elemento con el userName especificado
    }

    public boolean searchPassword(String data){
        Node<T> current = first;

        while (current != null) {
            if (current.getData() instanceof User) {
                User user = (User) current.getData();
                if (user.getPassword().equals(data)) {
                    return true;
                }
            }

            current = current.getNext();
        }
        return false;
    }

    public boolean searchProductName(String data){
        Node<T> current = first;

        while (current != null) {
            if (current.getData() instanceof Product) {
                if (((Product) current.getData()).getName().equalsIgnoreCase(data)) {
                    return true;
                }
            }

            current = current.getNext();
        }

        return false;
    }
    public Product searchProduct(String data){
        Node<T> current = first;

        while (current != null) {
            if (current.getData() instanceof Product) {
                if (((Product) current.getData()).getName().equalsIgnoreCase(data)) {
                    return ((Product) current.getData());
                }
            }

            current = current.getNext();
        }

        return null;
    }
    public boolean increaseProduct(String name, int quantity){
        Node<T> current = first;
        while (current != null){
            if(current.getData() instanceof Product){
                if(((Product) current.getData()).getName().equalsIgnoreCase(name)){
                    ((Product) current.getData()).setQuantity(((Product) current.getData()).getQuantity() + quantity);
                    return true;
                }
            }
            current = current.getNext();
        }
        return false;
    }
    public boolean decreseProduct(String nameProduct, int quantity){
        Node<T> actually = first;
        while (actually != null){
            if(actually.getData() instanceof Product){
                if(((Product) actually.getData()).getName().equalsIgnoreCase(nameProduct)){
                    ((Product) actually.getData()).setQuantity(((Product) actually.getData()).getQuantity() - quantity);
                    if(((Product) actually.getData()).getQuantity() > 0){
                        return true;
                    }else {
                        return false;
                    }
                }
            }
            actually = actually.getNext();
        }
        return false;
    }
    public Node<T> searchUser(String userName){
        Node<T> currentUser = first;

        while (currentUser != null){
            if (currentUser.getData() instanceof User){
                return currentUser;
            }

            currentUser = currentUser.getNext();
        }

        return null;
    }



    //cambiar conta
    public boolean contains(T data){
        if(first == null){
            return false;
        }
        else{
            return verifyExistence(data, first);
        }
    }

    public boolean verifyExistence(T target, Node<T> current){
        if(current.getData().equals(target)){
            return true;
        }
        else if(current.getNext() == null){
            return false;
        }
        else{
            return verifyExistence(target, current.getNext());
        }
    }

    // terminado
    public boolean newDelete(T data){
        Node<T> actually = first;
        if(actually.getBack() == null){
            actually = actually.getNext();
            actually.setBack(null);
            return  true;
        }else {
            while (actually != null){
                if(actually.getData().equals(data)){
                    Node<T> back = actually.getBack();
                    actually = actually.getNext();
                    actually.setBack(back);
                    size--;
                    return true;
                }
                actually = actually.getNext();
            }
        }
        return false;
    }

    // este metodo no referencia el nodo anterior
    public boolean delete(Node<T> previous,T data, Node<T> current){
        if(data.equals(current.getData())){
            if(current == first){
                first = first.getNext();
                if(size == 1){
                    last = null;
                }
                size--;
                return true;
            }
            else if(current == last){
                last = previous;
                last.setNext(null);
                size--;
                return true;
            }
            else{
                previous.setNext(current.getNext());
                size--;
                return true;
            }
        }
        else if(current.getNext() == null){
            return false;
        }
        else{
            return delete(current, data, current.getNext());
        }


    
    }


    public boolean isEmpty() {
        return first == null;
    }

    public int getSize(){
        return size;
    }

    public Node<T> getLast() {
        return last;
    }

    public Node<T> getFirst() {
        return first;
    }

    public String toString() {
        String result = "";
        Node<T> current = first;
        while (current != null) {
            result += current.getData() + "\n";
            current = current.getNext();
        }
        return result;
    }


}