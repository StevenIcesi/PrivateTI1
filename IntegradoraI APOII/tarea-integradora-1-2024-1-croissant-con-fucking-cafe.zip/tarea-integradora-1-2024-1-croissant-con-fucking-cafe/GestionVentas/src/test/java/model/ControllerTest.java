package model;

import org.junit.Test;
import customsExceptions.*;
import static org.junit.jupiter.api.Assertions.*;

public class ControllerTest {

    private Controller controller;

    public void setUp1(){
        controller = new Controller();
        controller.addUser("StevenRa","Kwoqdkwsqwjjjf1233","steven","ramirez","2005/05/05","cra 134443","Cali", "3017336129", "StevenRamireadnkjs@gmail.com");
    }
    public void setUp2(){
        controller = new Controller();
        controller.addProduct("toy car",5000,5);
        controller.addProduct("dolex",1500,10);
    }

    @Test
    public void testSignInIncorrectPassword() throws IncorrectPasswordException {
        setUp1();

        controller.addUser("testUser", "Test1234", "Test", "User", "2000/01/01", "Test Address", "Test City", "123456789", "test@example.com");

        try {
            controller.signIn("testUser", "Test1234");
        } catch (IncorrectPasswordException e) {
            assertThrows(IncorrectPasswordException.class, () -> controller.signIn("testUser2", "idk"));

        }
    }

    @Test
    public void testAddUser(){
        setUp1();
        boolean addUser = controller.addUser("FelipeRiascos", "13dkksdwidiPPP", "Felipe", "Riascos", "2009/02/06","cra 28b #4b 39", "Palmira", "30194613627", "Felipitoriascos23@gmail.com");
        assertTrue(addUser); // siempre va a dar true por que siempre esta contenido
    }

    @Test
    public void testAddUserDuplicate() {
        setUp1();
        controller.addUser("StevenRa", "Kwoqdkwsqwjjjf1233", "steven", "ramirez", "2005/05/05", "cra 134443", "Cali", "3017336129", "StevenRamireadnkjs@gmail.com");
        assertTrue(controller.addUser("StevenRa", "Kwoqdkwsqwjjjf1233", "steven", "ramirez", "2005/05/05", "cra 134443", "Cali", "3017336129", "StevenRamireadnkjs@gmail.com"));
    }

    @Test
    public void testAddProductDuplicate() {
        setUp2();
        assertTrue(controller.addProduct("toy car", 5000, 5));

    }

    @Test
    public void testAddProduct(){
        setUp2();

        boolean addProduct1 = controller.addProduct("Socks",5000,4);
        boolean addProduct2 = controller.addProduct("torta", 20000,34);
        assertFalse(addProduct1);
        assertFalse(addProduct2);

        //TODO revisar

    }


    @Test
    public void testDeleteProduct(){
        setUp2();
        try{
            assertFalse(controller.deleteProduct("dolex",10));
        } catch (NoProductExistent e){
            assertThrows(NoProductExistent.class, () -> controller.deleteProduct("Reloj", 4));
        }
    }



    @Test
    public void testDeleteProductSuccessfully() {
        setUp2();

        try{
            assertTrue(controller.deleteProduct("toy car", 2));
        } catch (NoProductExistent e){
            assertThrows(NoProductExistent.class, () -> controller.deleteProduct("toy motorcycle", 7));
        }
    }

    @Test
    public void testDeleteProductNotExist() {
        setUp2();
        try {
            assertFalse(controller.deleteProduct("torta", 3));
        } catch (NoProductExistent e){
            assertThrows(NoProductExistent.class, () -> controller.deleteProduct("manzana", 34));
        }
    }

    @Test
    public void testDeleteProductInsufficientQuantity() {
        setUp2();

        try{
            assertFalse(controller.deleteProduct("dolex", 20));
        } catch (NoProductExistent e){
            assertThrows(NoProductExistent.class, () -> controller.deleteProduct("dolex", 30));
        }
    }

    @Test
    public void testUpdateProduct() {
        setUp2();
        assertEquals("price updated succesfully", controller.updateProduct("dolex", 4.500, 24));
        assertEquals("price not updated", controller.updateProduct("shoes", 4.500, 24));
    }

    @Test
    public void testUpdateProductNotFound() {
        setUp2();

        assertEquals("price not updated", controller.updateProduct("nonexistentProduct", 2000.0, 5));
        assertEquals("price not updated", controller.updateProduct("nonexistentProduct", 2000.0, 5));
    }

     //TODO test

}