package model;

import customsExceptions.IncorrectPasswordException;
import customsExceptions.UniqueUserException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ExceptionTest {

    private Controller controller;

    public void setUp1(){
        controller = new Controller();

    }

    public void setUp2(){
        controller = new Controller();
        controller.addUser("valentinaH_21", "sdf43FDF", "valentina", "rodriguez", "2016, 10, 24", "Calle 34 carrera345", "Jamundi", "234234", "lskd@gmail.com");
    }

    @Test
    public void verifyPassword(){
        setUp1();

        //When the password contains only lowerCases and not numbers
        Assertions.assertThrows(IncorrectPasswordException.class, () -> controller.verifyPassword("qwerty"));

        //When the password contains only Upper and lowerCases, but not numbers
        Assertions.assertThrows(IncorrectPasswordException.class, () -> controller.verifyPassword("EdsfRTRdgWW"));

        //When the password contains upperCases, lowerCases and numbers
        try{
            Assertions.assertTrue(controller.verifyPassword("I don't know my password 123"));
        } catch (IncorrectPasswordException e){
            Assertions.assertThrows(e.getClass(), () -> controller.verifyPassword("I don't know my password 123"));
        }
    }

    @Test
    public void verifyUserName(){
        setUp2();

        try{
            //When the user name doesn't exist
            Assertions.assertFalse(controller.verifyUserName("Gabriel"));
        } catch (UniqueUserException e){
            //When the user name exist
            Assertions.assertThrows(UniqueUserException.class, () -> controller.verifyUserName("valentinaH_21"));
        }
    }

}
